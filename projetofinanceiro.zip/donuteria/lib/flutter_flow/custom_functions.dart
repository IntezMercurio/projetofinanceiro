import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

double? totalEntradas(
  List<double> somarValoresDinamicamente,
  List<String> tipo,
) {
  if (somarValoresDinamicamente == null || tipo == null) {
    return 0.0;
  }
  double somaTotal = 0.0;

  if (somarValoresDinamicamente.length != tipo.length) {
    return 0.0;
  }

  for (int i = 0; i < somarValoresDinamicamente.length; i++) {
    //Verifica se o tipo é uma "Entrada"
    if (tipo[i] == "Entrada") {
      somaTotal += somarValoresDinamicamente[i];
    }
  }

  return somaTotal;
}

double? totalSaidas(
  List<double> somarValoresDinamicamente,
  List<String> tipo,
) {
  if (somarValoresDinamicamente == null || tipo == null) {
    return 0.0;
  }
  double somaTotal = 0.0;

  if (somarValoresDinamicamente.length != tipo.length) {
    return 0.0;
  }

  for (int i = 0; i < somarValoresDinamicamente.length; i++) {
    // Verifica se o tipo é uma "Saída"
    if (tipo[i] == "Saída") {
      somaTotal += somarValoresDinamicamente[i];
    }
  }

  return somaTotal;
}

double? totalSaldo(
  List<double> somarValoresDinamicamente,
  List<String> tipo,
) {
  if (somarValoresDinamicamente == null || tipo == null) {
    return 0.0;
  }
  double somaTotal = 0.0;

  if (somarValoresDinamicamente.length != tipo.length) {
    return 0.0;
  }

  for (int i = 0; i < somarValoresDinamicamente.length; i++) {
    // Verifica se o tipo é uma "Saída"
    if (tipo[i] == "Saída" || tipo[i] == "Entrada") {
      somaTotal += somarValoresDinamicamente[i];
    }
  }

  return somaTotal;
}
