import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCaDRViRw-fXnMqcwa-Fkjjj94V3qMJ-3Y",
            authDomain: "projeto-financeiro-a4110.firebaseapp.com",
            projectId: "projeto-financeiro-a4110",
            storageBucket: "projeto-financeiro-a4110.firebasestorage.app",
            messagingSenderId: "681327910088",
            appId: "1:681327910088:web:9286c4f5a9b0a4a6db19fd",
            measurementId: "G-PV4M26P6H4"));
  } else {
    await Firebase.initializeApp();
  }
}
