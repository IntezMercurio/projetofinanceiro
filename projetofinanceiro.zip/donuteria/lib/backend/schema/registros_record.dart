import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegistrosRecord extends FirestoreRecord {
  RegistrosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "registro_id" field.
  int? _registroId;
  int get registroId => _registroId ?? 0;
  bool hasRegistroId() => _registroId != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "descricao" field.
  String? _descricao;
  String get descricao => _descricao ?? '';
  bool hasDescricao() => _descricao != null;

  // "categoria" field.
  String? _categoria;
  String get categoria => _categoria ?? '';
  bool hasCategoria() => _categoria != null;

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "valor" field.
  double? _valor;
  double get valor => _valor ?? 0.0;
  bool hasValor() => _valor != null;

  // "tipo" field.
  String? _tipo;
  String get tipo => _tipo ?? '';
  bool hasTipo() => _tipo != null;

  void _initializeFields() {
    _registroId = castToType<int>(snapshotData['registro_id']);
    _createdAt = snapshotData['created_at'] as DateTime?;
    _descricao = snapshotData['descricao'] as String?;
    _categoria = snapshotData['categoria'] as String?;
    _userId = snapshotData['user_id'] as String?;
    _valor = castToType<double>(snapshotData['valor']);
    _tipo = snapshotData['tipo'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('registros');

  static Stream<RegistrosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegistrosRecord.fromSnapshot(s));

  static Future<RegistrosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RegistrosRecord.fromSnapshot(s));

  static RegistrosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegistrosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegistrosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegistrosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegistrosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegistrosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegistrosRecordData({
  int? registroId,
  DateTime? createdAt,
  String? descricao,
  String? categoria,
  String? userId,
  double? valor,
  String? tipo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'registro_id': registroId,
      'created_at': createdAt,
      'descricao': descricao,
      'categoria': categoria,
      'user_id': userId,
      'valor': valor,
      'tipo': tipo,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegistrosRecordDocumentEquality implements Equality<RegistrosRecord> {
  const RegistrosRecordDocumentEquality();

  @override
  bool equals(RegistrosRecord? e1, RegistrosRecord? e2) {
    return e1?.registroId == e2?.registroId &&
        e1?.createdAt == e2?.createdAt &&
        e1?.descricao == e2?.descricao &&
        e1?.categoria == e2?.categoria &&
        e1?.userId == e2?.userId &&
        e1?.valor == e2?.valor &&
        e1?.tipo == e2?.tipo;
  }

  @override
  int hash(RegistrosRecord? e) => const ListEquality().hash([
        e?.registroId,
        e?.createdAt,
        e?.descricao,
        e?.categoria,
        e?.userId,
        e?.valor,
        e?.tipo
      ]);

  @override
  bool isValidKey(Object? o) => o is RegistrosRecord;
}
