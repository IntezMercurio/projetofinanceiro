import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = FlutterSecureStorage();
    await _safeInitAsync(() async {
      _valores = (await secureStorage.getStringList('ff_valores'))
              ?.map(double.parse)
              .toList() ??
          _valores;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  List<double> _valores = [23.0, 3.5, 1.5];
  List<double> get valores => _valores;
  set valores(List<double> value) {
    _valores = value;
    secureStorage.setStringList(
        'ff_valores', value.map((x) => x.toString()).toList());
  }

  void deleteValores() {
    secureStorage.delete(key: 'ff_valores');
  }

  void addToValores(double value) {
    valores.add(value);
    secureStorage.setStringList(
        'ff_valores', _valores.map((x) => x.toString()).toList());
  }

  void removeFromValores(double value) {
    valores.remove(value);
    secureStorage.setStringList(
        'ff_valores', _valores.map((x) => x.toString()).toList());
  }

  void removeAtIndexFromValores(int index) {
    valores.removeAt(index);
    secureStorage.setStringList(
        'ff_valores', _valores.map((x) => x.toString()).toList());
  }

  void updateValoresAtIndex(
    int index,
    double Function(double) updateFn,
  ) {
    valores[index] = updateFn(_valores[index]);
    secureStorage.setStringList(
        'ff_valores', _valores.map((x) => x.toString()).toList());
  }

  void insertAtIndexInValores(int index, double value) {
    valores.insert(index, value);
    secureStorage.setStringList(
        'ff_valores', _valores.map((x) => x.toString()).toList());
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: ListToCsvConverter().convert([value]));
}
