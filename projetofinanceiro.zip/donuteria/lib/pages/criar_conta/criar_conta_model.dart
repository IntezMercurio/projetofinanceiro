import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'criar_conta_widget.dart' show CriarContaWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CriarContaModel extends FlutterFlowModel<CriarContaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TextFieldNomedeUsuario widget.
  FocusNode? textFieldNomedeUsuarioFocusNode;
  TextEditingController? textFieldNomedeUsuarioTextController;
  String? Function(BuildContext, String?)?
      textFieldNomedeUsuarioTextControllerValidator;
  // State field(s) for TextFieldEmail widget.
  FocusNode? textFieldEmailFocusNode;
  TextEditingController? textFieldEmailTextController;
  String? Function(BuildContext, String?)?
      textFieldEmailTextControllerValidator;
  // State field(s) for TextFieldSenha widget.
  FocusNode? textFieldSenhaFocusNode;
  TextEditingController? textFieldSenhaTextController;
  late bool textFieldSenhaVisibility;
  String? Function(BuildContext, String?)?
      textFieldSenhaTextControllerValidator;
  // State field(s) for TextFieldConfirmarSenha widget.
  FocusNode? textFieldConfirmarSenhaFocusNode;
  TextEditingController? textFieldConfirmarSenhaTextController;
  late bool textFieldConfirmarSenhaVisibility;
  String? Function(BuildContext, String?)?
      textFieldConfirmarSenhaTextControllerValidator;

  @override
  void initState(BuildContext context) {
    textFieldSenhaVisibility = false;
    textFieldConfirmarSenhaVisibility = false;
  }

  @override
  void dispose() {
    textFieldNomedeUsuarioFocusNode?.dispose();
    textFieldNomedeUsuarioTextController?.dispose();

    textFieldEmailFocusNode?.dispose();
    textFieldEmailTextController?.dispose();

    textFieldSenhaFocusNode?.dispose();
    textFieldSenhaTextController?.dispose();

    textFieldConfirmarSenhaFocusNode?.dispose();
    textFieldConfirmarSenhaTextController?.dispose();
  }
}
