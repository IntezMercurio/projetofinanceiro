package com.mycompany.projetofinanceiro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
